#include"Obj.h"

Obj::Obj()
{
	pos_ = {};
	speed_ = {};
	size_ = {};
	radius_ = {};
}

Obj::~Obj()
{

}

void Obj::Update()
{

}

void Obj::Draw()
{

}